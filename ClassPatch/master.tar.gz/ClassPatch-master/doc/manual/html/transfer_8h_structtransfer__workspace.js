var transfer_8h_structtransfer__workspace =
[
    [ "HIS", "transfer_8h.html#aa81c012b8c0040001cedd2240dcf03be", null ],
    [ "HIS_allocated", "transfer_8h.html#aa82073c726b255bc6d85aa2ed7e59b2f", null ],
    [ "pBIS", "transfer_8h.html#ac0a4a7ac556b373d5afde27e75c1cba2", null ],
    [ "l_size", "transfer_8h.html#a8b96d30c1ef94e11aa4200c13e865d41", null ],
    [ "tau_size", "transfer_8h.html#a687f3dc5e1e24c16db6feb562de9477d", null ],
    [ "tau_size_max", "transfer_8h.html#ae456d6ef31a91fe0adc33af4260fe547", null ],
    [ "interpolated_sources", "transfer_8h.html#ad9de9e9288051713fff7e15845d379d8", null ],
    [ "sources", "transfer_8h.html#a7e1b7745f896916e019150d8b9261755", null ],
    [ "tau0_minus_tau", "transfer_8h.html#ac173b95d9119c27f08bb0eca6e0a585e", null ],
    [ "w_trapz", "transfer_8h.html#a494d2fb2fd39b12fcf6f9628724e9d28", null ],
    [ "chi", "transfer_8h.html#a48c29fdc48117dddcb0b4a872f1eea0a", null ],
    [ "cscKgen", "transfer_8h.html#a17cecce242bacda64a431ca5f1532a30", null ],
    [ "cotKgen", "transfer_8h.html#acd80ed43dfaa2eadf1695c8fd4f5b076", null ],
    [ "K", "transfer_8h.html#a3dfb6eba621f9b11a4b3edf4be42d176", null ],
    [ "sgnK", "transfer_8h.html#af43bd9bd9693d9dfda296b136adcfe80", null ],
    [ "tau0_minus_tau_cut", "transfer_8h.html#a2850c0e6097bdd5e63fce840c199c248", null ],
    [ "neglect_late_source", "transfer_8h.html#acc5b2260d1eb28b9fb12e7dd67b75e0f", null ]
];