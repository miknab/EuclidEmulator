var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwyz",
  1: "blnoprst",
  2: "bcilnopst",
  3: "bcgilnopstv",
  4: "abcdefghiklmnopqrstuvwyz",
  5: "efilprt",
  6: "dnrs",
  7: "_f",
  8: "ctuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

