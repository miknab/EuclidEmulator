var searchData=
[
  ['spectra_2ec',['spectra.c',['../spectra_8c.html',1,'']]],
  ['spectra_2eh',['spectra.h',['../spectra_8h.html',1,'']]]
];
