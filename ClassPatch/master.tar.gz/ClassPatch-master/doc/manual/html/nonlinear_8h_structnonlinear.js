var nonlinear_8h_structnonlinear =
[
    [ "method", "nonlinear_8h.html#aa5256a476f6fa766b8977272715be21a", null ],
    [ "k_size", "nonlinear_8h.html#a5337c7a8ffea7bb7f178d6bad11b5622", null ],
    [ "k", "nonlinear_8h.html#a74513b6640279e01850e7e8eb8976fb1", null ],
    [ "tau_size", "nonlinear_8h.html#a65b7e2e5ec57b04277e3797c6953e6ba", null ],
    [ "tau", "nonlinear_8h.html#a8457e334373ab9a00d3b5ca0958d79fe", null ],
    [ "nl_corr_density", "nonlinear_8h.html#a488af6d3cc6c44d56fd8cfdf38d4d75b", null ],
    [ "k_nl", "nonlinear_8h.html#afb3529188cde54269e8faeb411f323d4", null ],
    [ "nonlinear_verbose", "nonlinear_8h.html#a793810d8ed0e8a951293d0d4b1475c46", null ],
    [ "error_message", "nonlinear_8h.html#aea8dcc26882acb6c85a66e1aabcbc6c9", null ]
];