var spectra_8c =
[
    [ "spectra_cl_at_l", "spectra_8c.html#a474a08a4d11642f6e688524556442909", null ],
    [ "spectra_pk_at_z", "spectra_8c.html#aa30ca71782f1b8bf9aed8a3be0637959", null ],
    [ "spectra_pk_at_k_and_z", "spectra_8c.html#a31176b43d36e06fd89804ca7b6d77f6e", null ],
    [ "spectra_pk_nl_at_z", "spectra_8c.html#aba1b6d8a8efcf54131a9a7dac9361bd4", null ],
    [ "spectra_pk_nl_at_k_and_z", "spectra_8c.html#a381ba2cc19c5d43d481e816d73f2f58e", null ],
    [ "spectra_tk_at_z", "spectra_8c.html#ab59220fbc82fe2fa2997105af4d68187", null ],
    [ "spectra_tk_at_k_and_z", "spectra_8c.html#a99c7fafb33b166530fc1a9206feb453f", null ],
    [ "spectra_init", "spectra_8c.html#a192c3cc36d17f276ed7b5d7e485e70f1", null ],
    [ "spectra_free", "spectra_8c.html#acbfeac6ad88fa757677b47d76722aec3", null ],
    [ "spectra_indices", "spectra_8c.html#ab9a34eea930c566c6b47cc79da887853", null ],
    [ "spectra_cls", "spectra_8c.html#aff413243f74650e6eba56225ef30fb81", null ],
    [ "spectra_compute_cl", "spectra_8c.html#a202211a45920a13d8f0f0d545e45b226", null ],
    [ "spectra_k_and_tau", "spectra_8c.html#a8cf07f6b59b5c27822187b8dfb2e257e", null ],
    [ "spectra_pk", "spectra_8c.html#a1a6dd87098ad3da12ff3a685a6e32010", null ],
    [ "spectra_sigma", "spectra_8c.html#aad251bcc29d8eee1448d01e30260eb4a", null ],
    [ "spectra_matter_transfers", "spectra_8c.html#a5c100c52fd6479fee1c477d9fd841f28", null ],
    [ "spectra_output_tk_data", "spectra_8c.html#a4cf287a8b3796656614e40b9132f1176", null ]
];